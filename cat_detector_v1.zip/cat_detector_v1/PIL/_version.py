# Master version for Pillow
from __future__ import annotations

__version__ = "10.2.0"
