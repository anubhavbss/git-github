import json
import boto3
from PIL import Image
from io import BytesIO

def lambda_handler(event, context):
    bucket = "image-bucket-11"
    key = event['queryStringParameters']['photo_name']
    response = {'statusCode': 200, 'body': ''}
    
    try:
        image_data = boto3.client('s3').get_object(Bucket=bucket, Key=key)['Body'].read()
        is_cat = detect_cat(image_data)
        response['body'] = json.dumps({'is_cat': is_cat})
    except Exception as e:
        response['statusCode'] = 500
        response['body'] = json.dumps({'error': str(e)})
    
    return response

def detect_cat(image_data):
    try:
        image = Image.open(BytesIO(image_data))
        response = boto3.client('rekognition').detect_labels(Image={'Bytes': image_data}, MaxLabels=10, MinConfidence=80)
        labels = [label['Name'] for label in response.get('Labels', [])]
        return 'Cat' in labels
    except Exception as e:
        print(f"Error in detect_cat: {str(e)}")
        return False


